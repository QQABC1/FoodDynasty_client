<!-- src/components/common/Footer.vue -->
<template>
  <footer class="footer">
    <p>© 2024 美食应用 - 保留所有权利</p>
  </footer>
</template>

<style scoped>
.footer {
  padding: 1rem;
  text-align: center;
  background: #f5f5f5;
  margin-top: auto;
}
</style>