<!-- src/views/TablesPage.vue -->
<script setup>


// 定义餐桌数据（与 React 版本完全一致）
const tables = [
  { id: 1, number: "A01", capacity: 4, area: "A区", type: "方桌", available: true },
  { id: 2, number: "A02", capacity: 6, area: "A区", type: "圆桌", available: false },
  { id: 3, number: "B01", capacity: 2, area: "B区", type: "小桌", available: true },
  { id: 4, number: "B02", capacity: 8, area: "B区", type: "大圆桌", available: true },
  { id: 5, number: "C01", capacity: 4, area: "C区", type: "方桌", available: false },
  { id: 6, number: "C02", capacity: 6, area: "C区", type: "圆桌", available: true },
]

// 选择餐桌方法
const selectTable = (table) => {
  alert(`已选择餐桌 ${table.number}`)
}
</script>

<template>
    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-6xl mx-auto px-4">
        <!-- 标题与说明 -->
        <h1 class="text-3xl font-bold text-center mb-4 text-gray-800">选择餐桌</h1>
        <p class="text-center text-gray-600 mb-8">绿色表示空闲餐桌，红色表示已被占用</p>

        <!-- 餐桌网格 -->
        <div class="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
          <div 
            v-for="table in tables" 
            :key="table.id" 
            :class="[
              'border-2 rounded-lg p-6 text-center',
              table.available ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
            ]"
          >
            <!-- 桌号 -->
            <div 
              class="text-2xl font-bold mb-2" 
              :class="table.available ? 'text-green-600' : 'text-red-600'"
            >
              {{ table.number }}
            </div>

            <!-- 桌信息 -->
            <div class="space-y-2 text-sm text-gray-600 mb-4">
              <p><span class="font-medium">容纳人数:</span> {{ table.capacity }}人</p>
              <p><span class="font-medium">区域位置:</span> {{ table.area }}</p>
              <p><span class="font-medium">桌型:</span> {{ table.type }}</p>
            </div>

            <!-- 操作按钮（条件渲染） -->
            <template v-if="table.available">
              <button 
                @click="selectTable(table)" 
                class="w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-semibold transition-colors"
              >
                选择此餐桌
              </button>
            </template>
            <template v-else>
              <div class="w-full bg-red-500 text-white py-2 rounded-lg font-semibold">已被占用</div>
            </template>
          </div>
        </div>
      </div>
    </div>
</template>
