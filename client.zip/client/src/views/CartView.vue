<template>

    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-4xl mx-auto px-4">

        <!-- 顶部标题 + 清空按钮（模拟交互） -->
        <div class="flex justify-between items-center mb-8">
          <h1 class="text-3xl font-bold text-gray-800">购物车</h1>
          <button 
            @click="clearCart" 
            class="text-red-500 hover:text-red-600 font-medium"
          >
            清空购物车
          </button>
        </div>

        <!-- 空购物车提示（静态判断） -->
        <div 
          v-if="cartItems.length === 0" 
          class="text-center py-16"
        >
          <ShoppingCart class="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p class="text-gray-500 text-lg">购物车为空</p>
          <button
            @click="router.push('/menu')"
            class="mt-4 bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            去选购
          </button>
        </div>

        <!-- 购物车列表（静态数据渲染） -->
        <div 
          v-else 
          class="space-y-4"
        >
          <!-- 商品项循环 -->
          <div 
            v-for="(item, index) in cartItems" 
            :key="`${item.id}-${index}`" 
            class="bg-white rounded-lg shadow-md p-6"
          >
            <div class="flex items-center justify-between">
              <!-- 商品图片 + 信息 -->
              <div class="flex items-center space-x-4">
                <img
                  :src="item.image" 
                  :alt="item.name" 
                  class="w-16 h-16 object-cover rounded-lg"
                />
                <div>
                  <h3 class="font-semibold text-lg">{{ item.name }}</h3>
                  <p class="text-gray-600">单价: ¥{{ item.price }}</p>
                  <!-- 自定义项（模拟数据） -->
                  <p class="text-sm text-gray-500" v-if="item.customization">
                    {{ item.customization.size }} | {{ item.customization.spice }}
                  </p>
                </div>
              </div>

              <!-- 数量控制 + 小计 -->
              <div class="flex items-center space-x-4">
                <!-- 数量增减（模拟交互，仅改本地数据） -->
                <div class="flex items-center space-x-2">
                  <button
                    @click="updateQuantity(item.id, item.quantity - 1)"
                    class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300"
                  >
                    <Minus class="w-4 h-4" />
                  </button>
                  <span class="w-8 text-center font-semibold">{{ item.quantity }}</span>
                  <button
                    @click="updateQuantity(item.id, item.quantity + 1)"
                    class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300"
                  >
                    <Plus class="w-4 h-4" />
                  </button>
                </div>

                <!-- 小计金额 -->
                <div class="text-right">
                  <p class="font-semibold text-lg">¥{{ (item.price * item.quantity).toFixed(2) }}</p>
                </div>
              </div>
            </div>
          </div>

          <!-- 总计 + 结算（模拟交互） -->
          <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center text-xl font-bold">
              <span>总计:</span>
              <span class="text-orange-500">
                ¥{{ cartItems.reduce((t, i) => t + i.price * i.quantity, 0).toFixed(2) }}
              </span>
            </div>
            <button
              @click="checkout"
              class="w-full mt-4 bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-lg font-bold text-lg transition-colors"
            >
              结算
            </button>
          </div>
        </div>

      </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'          // 路由（可选，可替换为 alert）
import { ShoppingCart, Minus, Plus } from 'lucide-vue-next' // 图标

// ---------------------- 静态数据 ----------------------
const cartItems = ref([
  {
    id: 1,
    name: "宫保鸡丁",
    price: 28.0,
    image: "/placeholder.svg?height=200&width=300", // 需放 public 目录
    quantity: 2,
    customization: { size: "中份", spice: "微辣" },
  },
  {
    id: 2,
    name: "秘制红烧排骨面",
    price: 68.0,
    image: "/placeholder.svg?height=200&width=300",
    quantity: 1,
    customization: null,
  },
])

// ---------------------- 交互逻辑（纯模拟，无全局状态） ----------------------
const router = useRouter()

// 更新数量（本地数组操作）
const updateQuantity = (id, newQuantity) => {
  const index = cartItems.value.findIndex(item => item.id === id)
  if (index === -1) return
  if (newQuantity <= 0) {
    cartItems.value.splice(index, 1) // 数量≤0则移除
  } else {
    cartItems.value[index].quantity = newQuantity // 更新数量
  }
}

// 清空购物车（本地数组清空）
const clearCart = () => {
  cartItems.value = []
  alert('购物车已清空（模拟）')
}

// 结算（本地数组清空 + 提示）
const checkout = () => {
  if (cartItems.value.length === 0) return
  alert('订单提交成功（模拟）')
  cartItems.value = []
  router.push('/orders') // 假设 /orders 存在，可注释掉仅保留 alert
}
</script>

<style scoped>
/* 局部样式（如需微调，优先复用 Tailwind 类） */
</style>