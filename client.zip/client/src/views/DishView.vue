<template>
    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-4xl mx-auto px-4">
        <!-- 返回按钮 -->
        <button
          @click="router.push('/menu')"
          class="mb-6 flex items-center text-orange-500 hover:text-orange-600"
        >
          <ArrowLeft class="w-5 h-5 mr-2" />
          返回菜单
        </button>

        <!-- 菜品卡片 -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
          <!-- 菜品主图 + 渐变遮罩 -->
          <div class="relative">
            <img
              :src="selectedDish.image || '/placeholder.svg'"
              :alt="selectedDish.name"
              class="w-full h-96 object-cover"
            />
            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
              <h1 class="text-3xl font-bold text-white mb-2">{{ selectedDish.name }}</h1>
              <div class="flex items-center space-x-4">
                <span class="text-2xl font-bold text-orange-400">¥{{ selectedDish.price }}</span>
                <span class="bg-orange-500 text-white px-3 py-1 rounded-full text-sm">招牌菜</span>
              </div>
            </div>
          </div>

          <!-- 菜品详情内容 -->
          <div class="p-8">
            <div class="grid md:grid-cols-2 gap-8">
              <!-- 左侧：菜品介绍 -->
              <div>
                <h2 class="text-xl font-bold mb-4 text-gray-800">菜品介绍</h2>
                <p class="text-gray-600 mb-6">{{ selectedDish.fullDescription }}</p>

                <h3 class="text-lg font-semibold mb-3 text-gray-800">菜品信息</h3>
                <div class="space-y-2 text-sm text-gray-600">
                  <p>
                    <span class="font-medium">主要食材:</span> {{ selectedDish.ingredients }}
                  </p>
                  <p>
                    <span class="font-medium">烹饪方式:</span> {{ selectedDish.cookingMethod }}
                  </p>
                  <p>
                    <span class="font-medium">口味特色:</span> {{ selectedDish.flavor }}
                  </p>
                </div>
              </div>

              <!-- 右侧：定制选项 -->
              <div>
                <h2 class="text-xl font-bold mb-4 text-gray-800">定制选项</h2>

                <div class="space-y-6">
                  <!-- 分量选择 -->
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">分量选择</label>
                    <div class="flex space-x-3">
                      <button
                        v-for="size in ['标准份', '大份']"
                        :key="size"
                        @click="dishCustomization.size = size"
                        :class="`px-4 py-2 rounded-lg font-medium transition-colors ${
                          dishCustomization.size === size 
                            ? 'bg-orange-500 text-white' 
                            : 'bg-gray-200 text-gray-700'
                        }`"
                      >
                        {{ size }}
                      </button>
                    </div>
                  </div>

                  <!-- 口味选择 -->
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">口味选择</label>
                    <div class="flex space-x-3">
                      <button
                        v-for="spice in ['原味', '微辣', '中辣', '重辣']"
                        :key="spice"
                        @click="dishCustomization.spice = spice"
                        :class="`px-4 py-2 rounded-lg font-medium transition-colors ${
                          dishCustomization.spice === spice 
                            ? 'bg-orange-500 text-white' 
                            : 'bg-gray-200 text-gray-700'
                        }`"
                      >
                        {{ spice }}
                      </button>
                    </div>
                  </div>

                  <!-- 备注信息 -->
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">备注信息</label>
                    <textarea
                      v-model="dishCustomization.note"
                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      rows="3"
                      placeholder="请输入特殊要求..."
                    />
                  </div>

                  <!-- 加入购物车按钮 -->
                  <button
                    @click="handleAddToCart"
                    class="w-full bg-gradient-to-r from-orange-400 to-orange-600 text-white py-4 rounded-lg font-bold text-lg hover:from-orange-500 hover:to-orange-700 transition-all"
                  >
                    加入购物车
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowLeft } from 'lucide-vue-next'


// ---------------------- 静态数据（模拟 selectedDish） ----------------------
const selectedDish = ref({
  id: 1,
  name: "宫保鸡丁",
  price: 28.0,
  image: "/placeholder.svg?height=400&width=800", // 替换为在线地址或本地文件
  fullDescription: "宫保鸡丁是一道闻名中外的特色传统名菜，属川菜系。此菜成菜后，红而不辣、辣而不猛、香辣味浓、肉质滑脆。",
  ingredients: "鸡胸肉、花生米、干辣椒、花椒",
  cookingMethod: "爆炒",
  flavor: "香辣微甜",
})

// ---------------------- 定制选项状态 ----------------------
const dishCustomization = ref({
  size: "标准份",
  spice: "原味",
  note: "",
})

// ---------------------- 路由与交互 ----------------------
const router = useRouter()

// 模拟：检查菜品数据是否存在，不存在则跳转菜单页
onMounted(() => {
  if (!selectedDish.value) {
    router.push('/menu')
  }
})

// 监听 selectedDish 变化，不存在则跳转
watch(selectedDish, (newVal) => {
  if (!newVal) {
    router.push('/menu')
  }
})

// 加入购物车（模拟交互）
const handleAddToCart = () => {
  alert("已加入购物车！")
  router.push('/menu') // 跳转菜单页
}
</script>

<style scoped>
/* 保持样式与原设计一致，无需额外添加 */
</style>