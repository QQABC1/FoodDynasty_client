<template>
    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-6xl mx-auto px-4">
        <!-- 标题 -->
        <h1 class="text-3xl font-bold text-center mb-8 text-gray-800">我的订单</h1>

        <!-- 订单选项卡（与 React 类名完全一致） -->
        <div class="flex justify-center mb-8">
          <div class="bg-white rounded-lg shadow-md p-2 flex space-x-2">
            <button
              v-for="tab in orderTabs"
              :key="tab"
              @click="selectedOrderTab = tab"
              :class="`px-6 py-2 rounded-md font-medium transition-all ${
                selectedOrderTab === tab ? 'bg-orange-500 text-white' : 'text-gray-600 hover:text-orange-500'
              }`"
            >
              {{ tab }}
            </button>
          </div>
        </div>

        <!-- 订单列表（严格复用 React 布局） -->
        <div class="space-y-6">
          <div 
            v-for="order in filteredOrders" 
            :key="order.id" 
            class="bg-white rounded-lg shadow-md p-6"  
          >
            <!-- 订单头部信息 -->
            <div class="flex justify-between items-start mb-4">
              <div>
                <h3 class="font-semibold text-lg">订单号: {{ order.orderNumber }}</h3>
                <p class="text-gray-600">下单时间: {{ order.orderTime }}</p>
              </div>
              <span 
                :class="`px-3 py-1 rounded-full text-sm font-medium ${getOrderStatusClass(order.status)}`"
              >
                {{ order.status }}
              </span>
            </div>

            <!-- 菜品列表（带分隔线） -->
            <div class="border-t pt-4">  <!-- 与 React 分隔线样式一致 -->
              <h4 class="font-medium mb-3">菜品列表:</h4>
              <div class="space-y-2">
                <div 
                  v-for="item in order.items" 
                  :key="item.id" 
                  class="flex justify-between text-sm"  
                >
                  <span>
                    {{ item.name }} × {{ item.quantity }}
                  </span>
                  <span>¥{{ (item.price * item.quantity).toFixed(2) }}</span>
                </div>
              </div>
            </div>

            <!-- 订单底部操作区 -->
            <div class="border-t pt-4 flex justify-between items-center">  <!-- 与 React 底部样式一致 -->
              <div class="text-lg font-bold">
                总计: <span class="text-orange-500">¥{{ order.total.toFixed(2) }}</span>
              </div>
              <div class="space-x-3">  <!-- 按钮间距与 React 一致 -->
                <!-- 待付款状态按钮 -->
                <template v-if="order.status === '待付款'">
                  <button
                    @click="payOrder(order.id)"
                    class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                  >
                    立即支付
                  </button>
                  <button
                    @click="cancelOrder(order.id)"
                    class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                  >
                    取消订单
                  </button>
                </template>

                <!-- 已完成状态按钮 -->
                <button 
                  v-else-if="order.status === '已完成'"
                  class="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                  评价订单
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
import { ref, computed } from 'vue'


// 模拟订单数据（与 React 数据结构完全一致）
const orders = ref([
  {
    id: 1,
    orderNumber: "FD20250708001",
    orderTime: "2025-07-08 14:30:25",
    status: "待付款",
    items: [
      { id: 1, name: "宫保鸡丁", quantity: 2, price: 28.0 },
      { id: 2, name: "银耳莲子汤", quantity: 1, price: 18.0 }
    ],
    total: 74.0
  },
  {
    id: 2,
    orderNumber: "FD20250707002",
    orderTime: "2025-07-07 18:45:10",
    status: "已完成",
    items: [
      { id: 3, name: "秘制红烧排骨面", quantity: 1, price: 68.0 },
      { id: 4, name: "凉拌黄瓜", quantity: 1, price: 12.0 }
    ],
    total: 80.0
  },
  {
    id: 3,
    orderNumber: "FD20250706003",
    orderTime: "2025-07-06 12:15:30",
    status: "待评价",
    items: [
      { id: 5, name: "鲜榨橙汁", quantity: 2, price: 15.0 },
      { id: 1, name: "宫保鸡丁", quantity: 1, price: 28.0 }
    ],
    total: 58.0
  }
])

// 订单选项卡状态（与 React useState 逻辑一致）
const orderTabs = ["全部订单", "待付款", "待评价"]
const selectedOrderTab = ref("全部订单")

// 筛选订单（与 React 筛选逻辑一致）
const filteredOrders = computed(() => {
  return selectedOrderTab.value === "全部订单"
    ? orders.value
    : orders.value.filter(order => order.status === selectedOrderTab.value)
})

// 订单状态样式映射（与 React getOrderStatusClass 完全一致）
const getOrderStatusClass = (status) => {
  switch (status) {
    case "待付款":
      return "bg-yellow-100 text-yellow-800"
    case "已完成":
      return "bg-green-100 text-green-800"
    case "待评价":
      return "bg-blue-100 text-blue-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

// 支付订单逻辑（与 React payOrder 一致）
const payOrder = (orderId) => {
  orders.value = orders.value.map(order => 
    order.id === orderId ? { ...order, status: "已完成" } : order
  )
  alert("支付成功！")
}

// 取消订单逻辑（与 React cancelOrder 一致）
const cancelOrder = (orderId) => {
  if (confirm("确定要取消订单吗？")) {
    orders.value = orders.value.filter(order => order.id !== orderId)
    alert("订单已取消")
  }
}
</script>

<style scoped>
/* 保持与 React 一致的样式隔离，不添加额外样式 */
</style>