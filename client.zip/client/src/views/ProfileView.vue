<template>
    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-2xl mx-auto px-4">
        <h1 class="text-3xl font-bold text-center mb-8 text-gray-800">个人中心</h1>

        <div class="bg-white rounded-lg shadow-lg p-8">
          <!-- User Info -->
          <div class="text-center mb-8">
            <div class="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserIcon class="w-10 h-10 text-white" />
            </div>
            <h2 class="text-2xl font-bold text-gray-800">{{ customer.name }}</h2>
            <p class="text-gray-600">用户ID: {{ customer.id }}</p>
          </div>

          <!-- User Details -->
          <div class="space-y-6">
            <div class="flex justify-between items-center py-4 border-b">
              <span class="font-medium text-gray-700">电话号码</span>
              <span class="text-gray-600">{{ customer.phone }}</span>
            </div>

            <div class="flex justify-between items-center py-4 border-b">
              <span class="font-medium text-gray-700">账户余额</span>
              <span class="text-2xl font-bold text-orange-500">¥{{ customer.balance.toFixed(2) }}</span>
            </div>

            <!-- Action Buttons -->
            <div class="grid md:grid-cols-3 gap-4 pt-6">
              <button
                @click="showRecharge = true"
                class="bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold transition-colors"
              >
                充值
              </button>
              <button class="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold transition-colors">
                修改密码
              </button>
              <button class="bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-semibold transition-colors">
                编辑资料
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Recharge Modal -->
      <div v-if="showRecharge" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-8 max-w-md w-full mx-4">
          <h3 class="text-xl font-bold mb-4">账户充值</h3>
          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">充值金额</label>
              <input
                v-model="rechargeAmount"
                type="number"
                min="1"
                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            <div class="flex space-x-4">
              <button
                @click="recharge"
                class="flex-1 bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold transition-colors"
              >
                确认充值
              </button>
              <button
                @click="showRecharge = false"
                class="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors"
              >
                取消
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import Layout from '../components/common/Layout.vue'

// 静态用户数据
const customer = ref({
  id: '123456',
  name: '张三',
  phone: '13800138000',
  balance: 100.00
})

// 状态管理
const showRecharge = ref(false)
const rechargeAmount = ref('')

// 充值功能
const recharge = () => {
  if (rechargeAmount.value && parseFloat(rechargeAmount.value) > 0) {
    const newBalance = customer.value.balance + parseFloat(rechargeAmount.value)
    customer.value = { ...customer.value, balance: newBalance }
    alert(`充值成功！当前余额：¥${newBalance.toFixed(2)}`)
    showRecharge.value = false
    rechargeAmount.value = ''
  }
}
</script>
  