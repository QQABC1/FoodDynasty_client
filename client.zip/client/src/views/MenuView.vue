<!-- src/views/MenuPage.vue -->
<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

// 模拟 MenuItem 类型（TypeScript 可单独定义 interface）
const menuItems = [
  {
    id: 1,
    name: "宫保鸡丁",
    description: "经典川菜，鸡肉嫩滑，花生香脆",
    price: 28.0,
    category: "热菜",
    image: "/placeholder.svg?height=200&width=300", // 需确保 public 目录有此文件
    fullDescription:
      "宫保鸡丁是一道闻名中外的特色传统名菜，属川菜系。此菜成菜后，红而不辣、辣而不猛、香辣味浓、肉质滑脆。",
    ingredients: "鸡胸肉、花生米、干辣椒、花椒",
    cookingMethod: "爆炒",
    flavor: "香辣微甜",
  },
  {
    id: 2,
    name: "秘制红烧排骨面",
    description: "秘制汤底，排骨软烂，面条劲道",
    price: 68.0,
    category: "热菜",
    image: "/placeholder.svg?height=200&width=300",
    fullDescription: "选用优质排骨，经过长时间炖煮，肉质软烂，汤汁浓郁。配以手工拉面，口感层次丰富。",
    ingredients: "排骨、手工面条、青菜、香菇",
    cookingMethod: "炖煮",
    flavor: "鲜香浓郁",
  },
  {
    id: 3,
    name: "凉拌黄瓜",
    description: "清爽开胃，酸甜可口",
    price: 12.0,
    category: "凉菜",
    image: "/placeholder.svg?height=200&width=300",
    fullDescription: "选用新鲜黄瓜，切丝后用特制调料凉拌，口感清脆，是夏日开胃的首选。",
    ingredients: "黄瓜、蒜泥、香醋、香油",
    cookingMethod: "凉拌",
    flavor: "酸甜清香",
  },
  {
    id: 4,
    name: "银耳莲子汤",
    description: "滋补养颜，清甜润燥",
    price: 18.0,
    category: "汤类",
    image: "/placeholder.svg?height=200&width=300",
    fullDescription: "精选优质银耳和莲子，慢火炖煮，具有滋阴润肺、养颜美容的功效。",
    ingredients: "银耳、莲子、冰糖、枸杞",
    cookingMethod: "炖煮",
    flavor: "清甜润燥",
  },
  {
    id: 5,
    name: "鲜榨橙汁",
    description: "新鲜橙子现榨，维C丰富",
    price: 15.0,
    category: "饮品",
    image: "/placeholder.svg?height=200&width=300",
    fullDescription: "选用新鲜橙子现场榨制，保留最多的维生素C和天然果香。",
    ingredients: "新鲜橙子",
    cookingMethod: "现榨",
    flavor: "酸甜清香",
  },
]

// 分类筛选
const categories = ["全部", "热菜", "凉菜", "汤类", "饮品"]
const selectedCategory = ref('全部')

// 路由跳转
const router = useRouter()

// 模拟全局状态（实际建议用 Pinia，此处简化演示）
const setSelectedDish = (dish) => {
  // 实际需更新全局状态（如 Pinia 的 store）
  console.log('选中菜品：', dish) 
}

// 过滤菜单
const filteredMenuItems = computed(() => {
  return selectedCategory.value === '全部' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory.value)
})

// 查看详情逻辑
const viewDishDetail = (dish) => {
  setSelectedDish(dish)
  router.push('/dish-detail') // 需确保路由存在
}
</script>

<template>
    <div class="bg-gray-50 min-h-screen py-8">
      <div class="max-w-7xl mx-auto px-4">
        <!-- 标题 -->
        <h1 class="text-4xl font-bold text-center mb-8 text-gray-800">精选菜单</h1>

        <!-- 分类标签栏 -->
        <div class="flex justify-center mb-8">
          <div class="bg-white rounded-lg shadow-md p-2 flex space-x-2">
            <button 
              v-for="category in categories" 
              :key="category" 
              @click="selectedCategory = category"
              :class="`px-6 py-2 rounded-md font-medium transition-all ${
                selectedCategory === category ? 'bg-orange-500 text-white' : 'text-gray-600 hover:text-orange-500'
              }`"
            >
              {{ category }}
            </button>
          </div>
        </div>

        <!-- 菜单列表 -->
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div 
            v-for="item in filteredMenuItems" 
            :key="item.id" 
            class="bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg shadow-lg overflow-hidden text-white"
          >
            <!-- 菜品图片 -->
            <img 
              :src="item.image" 
              :alt="item.name" 
              class="w-full h-48 object-cover" 
            />
            <!-- 菜品信息 -->
            <div class="p-6">
              <h3 class="text-xl font-bold mb-2">{{ item.name }}</h3>
              <p class="text-orange-100 mb-4 text-sm">{{ item.description }}</p>
              <div class="flex justify-between items-center">
                <span class="text-2xl font-bold">¥{{ item.price }}</span>
                <button 
                  @click="viewDishDetail(item)"
                  class="bg-white text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                >
                  查看详情
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

</template>

<style scoped>
/* 局部样式（若需补充） */
</style>